import { h, app } from "olived";

app({
  view: () => h("main", {}, "Hello Olived + Render!"),
  node: document.getElementById("app"),
});
